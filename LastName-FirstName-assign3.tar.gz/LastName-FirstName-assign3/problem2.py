import sys
import hatchet as ht
gf = ht.GraphFrame.from_caliper("lulesh-64cores.json")
X = int(sys.argv[1])
imbalance_df = gf.load_imbalance(metric="time (exclusive)")
sorted_df = imbalance_df.sort_values(by="imbalance", ascending=False)
target_row = sorted_df.iloc[X - 1]
function_node = target_row["node"]
processes = gf.dataframe.loc[function_node]["processes"]
print(processes)
