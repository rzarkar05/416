#!/usr/bin/env python3

import sys
import hatchet as ht
gf8 = ht.GraphFrame.from_caliper("lulesh-8cores.json")
gf64 = ht.GraphFrame.from_caliper("lulesh-64cores.json")
N = int(sys.argv[1])
gf8 = gf8.drop_index_levels()
gf64 = gf64.drop_index_levels()
diff_gf = gf64 - gf8
df = diff_gf.dataframe
sorted_df = df.sort_values(by="time (exclusive)", ascending=False)
for idx, row in sorted_df.head(N).iterrows():
    print(f"{row['name']} {row['time (exclusive)']}")
