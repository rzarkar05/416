#!/usr/bin/env python3

import sys
import hatchet as ht
gf = ht.GraphFrame.from_caliper("lulesh-1core.json")
N = int(sys.argv[1])
df = gf.dataframe
sorted_df = df.sort_values(by="time (exclusive)", ascending=False)
for idx, row in sorted_df.head(N).iterrows():
    print(f"{row['name']} {row['time (exclusive)']}")
